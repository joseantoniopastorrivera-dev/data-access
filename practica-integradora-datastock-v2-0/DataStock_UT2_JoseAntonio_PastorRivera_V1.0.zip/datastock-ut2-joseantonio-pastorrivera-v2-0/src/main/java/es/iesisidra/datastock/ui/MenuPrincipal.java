package es.iesisidra.datastock.ui;

import es.iesisidra.datastock.ficheros.ComprobadorRutas;
import es.iesisidra.datastock.ficheros.ExploradorRutas;
import es.iesisidra.datastock.ficheros.ExportacionException;
import es.iesisidra.datastock.ficheros.ExportadorCatalogo;
import es.iesisidra.datastock.ficheros.ExportadorJson;
import es.iesisidra.datastock.ficheros.ExportadorXml;
import es.iesisidra.datastock.ficheros.ImportacionException;
import es.iesisidra.datastock.ficheros.ImportadorCatalogo;
import es.iesisidra.datastock.ficheros.ImportadorJson;
import es.iesisidra.datastock.ficheros.ImportadorXml;
import es.iesisidra.datastock.ficheros.ResultadoImportacion;
import es.iesisidra.datastock.ficheros.SerializadorInventario;
import es.iesisidra.datastock.modelo.Producto;
import es.iesisidra.datastock.servicio.Inventario;
import es.iesisidra.datastock.util.ColoresConsola;
import es.iesisidra.datastock.util.LectorConsola;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

/**
 * Menú principal de DataStock. Las opciones 1-6 (UT1) trabajan con el inventario
 * en memoria; la opción 7 (UT2) trabaja con MySQL. Los dos almacenes NO se
 * sincronizan solos: solo la opción 7.8 copia productos de memoria a MySQL.
 * <p>Esta clase solo muestra opciones, pide datos y presenta resultados. El
 * acceso a ficheros, la validación y el procesamiento están delegados en los
 * paquetes {@code ficheros}, {@code validacion} y {@code servicio}.</p>
 */
public class MenuPrincipal {
    private final Inventario inventario;
    private final ExploradorRutas explorador = new ExploradorRutas();
    private final ImportadorCatalogo importadorJson = new ImportadorJson();
    private final ImportadorCatalogo importadorXml = new ImportadorXml();
    private final ExportadorCatalogo exportadorJson = new ExportadorJson();
    private final ExportadorCatalogo exportadorXml = new ExportadorXml();
    private final SerializadorInventario serializador = new SerializadorInventario();
    /** UT2: menú JDBC. Recibe el inventario solo para la opción 7.8 (copiar memoria a MySQL). */
    private final MenuMySQL menuMySQL;

    /** @param inventario colección común de productos de esta ejecución. */
    public MenuPrincipal(Inventario inventario) {
        this.inventario = inventario;
        this.menuMySQL = new MenuMySQL(inventario);
    }

    /** Ejecuta el menú principal hasta que el usuario selecciona salir. */
    public void iniciar() {
        int opcion;
        do {
            mostrarCabecera();
            System.out.println("1. Explorar ficheros y directorios (UT1)");
            System.out.println("2. Importar productos desde JSON (UT1)");
            System.out.println("3. Importar productos desde XML (UT1)");
            System.out.println("4. Consultar productos en memoria (UT1)");
            System.out.println("5. Exportar productos (UT1)");
            System.out.println("6. Guardar y recuperar inventario (UT1)");
            System.out.println("7. Gestionar base de datos MySQL (UT2)");
            System.out.println("0. Salir");
            opcion = LectorConsola.leerOpcion("Selecciona una opción: ", 0, 7);
            switch (opcion) {
                case 1 -> explorarRuta();
                case 2 -> importar("JSON", importadorJson);
                case 3 -> importar("XML", importadorXml);
                case 4 -> menuConsultas();
                case 5 -> menuExportaciones();
                case 6 -> menuSerializacion();
                case 7 -> menuMySQL.iniciar();
                case 0 -> System.out.println(ColoresConsola.pintar("Hasta pronto.", ColoresConsola.VERDE));
                default -> throw new IllegalStateException("Opción inesperada");
            }
        } while (opcion != 0);
    }

    private void mostrarCabecera() {
        System.out.println(ColoresConsola.pintar("\n================================================", ColoresConsola.CIAN));
        System.out.println(ColoresConsola.pintar("         DATASTOCK - GESTIÓN DE INVENTARIO", ColoresConsola.NEGRITA));
        System.out.println(ColoresConsola.pintar("           FASE 2 - UT1 + UT2 (MySQL)", ColoresConsola.CIAN));
        System.out.println(ColoresConsola.pintar("================================================", ColoresConsola.CIAN));
        System.out.println(ColoresConsola.pintar("Productos en memoria (UT1): " + inventario.tamano(), ColoresConsola.GRIS));
    }

    /** RF-FIC-01: pide la ruta y delega la exploración en ExploradorRutas. */
    private void explorarRuta() {
        System.out.println("\n===== EXPLORAR RUTA =====");
        String ruta = LectorConsola.leerTexto("Ruta: ");
        explorador.explorar(ruta);
        LectorConsola.pausar();
    }

    /**
     * RF-FIC-02 y RF-FIC-03: pide la ruta, delega la importación y muestra el resumen.
     * @param formato   texto para el título ("JSON" o "XML")
     * @param importador objeto que sabe leer ese formato
     */
    private void importar(String formato, ImportadorCatalogo importador) {
        System.out.println("\n===== IMPORTAR " + formato + " =====");
        String ruta = LectorConsola.leerTexto("Ruta: ");
        try {
            ResultadoImportacion resultado = importador.importar(ruta, inventario);
            mostrarResumen(resultado);
        } catch (ImportacionException ex) {
            System.out.println(ColoresConsola.pintar("Importación cancelada: " + ex.getMessage(), ColoresConsola.ROJO));
            System.out.println("No se ha añadido ningún producto al inventario.");
        }
        LectorConsola.pausar();
    }

    /** Muestra el resumen común de una importación (JSON o XML). */
    private void mostrarResumen(ResultadoImportacion resultado) {
        System.out.println("Productos encontrados: " + resultado.getEncontrados());
        System.out.println("Importados: " + resultado.getImportados() + " | Rechazados: " + resultado.getRechazados());
        if (resultado.getIncidencias().isEmpty()) {
            System.out.println(ColoresConsola.pintar("Importación finalizada.", ColoresConsola.VERDE));
        } else {
            System.out.println("INCIDENCIAS:");
            for (String incidencia : resultado.getIncidencias()) {
                System.out.println("  - " + incidencia);
            }
            System.out.println(ColoresConsola.pintar("Importación finalizada con incidencias.", ColoresConsola.AMARILLO));
        }
    }

    private void menuConsultas() {
        int opcion;
        do {
            System.out.println("\n---------- CONSULTA DE PRODUCTOS ----------");
            System.out.println("1. Listar todos los productos");
            System.out.println("2. Buscar producto por código");
            System.out.println("3. Buscar productos por nombre");
            System.out.println("0. Volver al menú principal");
            opcion = LectorConsola.leerOpcion("Selecciona una opción: ", 0, 3);
            switch (opcion) {
                case 1 -> listarProductos();
                case 2 -> buscarPorCodigo();
                case 3 -> buscarPorNombre();
                case 0 -> { }
                default -> throw new IllegalStateException("Opción inesperada");
            }
        } while (opcion != 0);
    }

    /** RF-FIC-04.1: listado completo ordenado por código. */
    private void listarProductos() {
        if (avisarSiVacio()) {
            return;
        }
        List<Producto> productos = inventario.listarOrdenado();
        mostrarTabla(productos);
        System.out.println("Total: " + productos.size() + " productos");
        LectorConsola.pausar();
    }

    /** RF-FIC-04.2: búsqueda por código exacto. */
    private void buscarPorCodigo() {
        if (avisarSiVacio()) {
            return;
        }
        String codigo = LectorConsola.leerTexto("Código: ");
        if (codigo.isBlank()) {
            System.out.println(ColoresConsola.pintar("Debes escribir un código.", ColoresConsola.AMARILLO));
        } else {
            inventario.buscarPorCodigo(codigo).ifPresentOrElse(
                    this::mostrarFicha,
                    () -> System.out.println(ColoresConsola.pintar(
                            "No existe ningún producto con el código " + codigo.trim() + ".", ColoresConsola.AMARILLO)));
        }
        LectorConsola.pausar();
    }

    /** RF-FIC-04.3: búsqueda por fragmento del nombre. */
    private void buscarPorNombre() {
        if (avisarSiVacio()) {
            return;
        }
        String texto = LectorConsola.leerTexto("Texto a buscar en el nombre: ");
        if (texto.isBlank()) {
            System.out.println(ColoresConsola.pintar("Debes escribir algún texto.", ColoresConsola.AMARILLO));
        } else {
            List<Producto> encontrados = inventario.buscarPorNombre(texto);
            if (encontrados.isEmpty()) {
                System.out.println(ColoresConsola.pintar(
                        "Ningún producto contiene «" + texto.trim() + "» en su nombre.", ColoresConsola.AMARILLO));
            } else {
                mostrarTabla(encontrados);
                System.out.println("Coincidencias: " + encontrados.size());
            }
        }
        LectorConsola.pausar();
    }

    /** Muestra un aviso si el inventario está vacío. @return true si lo estaba */
    private boolean avisarSiVacio() {
        if (!inventario.estaVacio()) {
            return false;
        }
        System.out.println(ColoresConsola.pintar(
                "El inventario está vacío. Importa un catálogo JSON o XML (opciones 2 y 3) o recupera un .dat (opción 6).",
                ColoresConsola.AMARILLO));
        LectorConsola.pausar();
        return true;
    }

    private void mostrarTabla(List<Producto> productos) {
        String formato = "%-12s %-32s %10s %6s %5s %5s%n";
        System.out.printf(formato, "CÓDIGO", "NOMBRE", "PRECIO", "STOCK", "CAT.", "PROV.");
        for (Producto p : productos) {
            System.out.printf(formato, p.getCodigo(), recortar(p.getNombre(), 32),
                    p.getPrecio().toPlainString() + " €", p.getStock(), p.getCategoriaId(), p.getProveedorId());
        }
    }

    private void mostrarFicha(Producto p) {
        System.out.println("Código: " + p.getCodigo());
        System.out.println("Nombre: " + p.getNombre());
        System.out.println("Precio: " + p.getPrecio().toPlainString() + " € | Stock: " + p.getStock());
        System.out.println("Categoría: " + p.getCategoriaId() + " | Proveedor: " + p.getProveedorId());
    }

    /** Acorta los nombres largos para que no descuadren la tabla. */
    private String recortar(String texto, int maximo) {
        return texto.length() <= maximo ? texto : texto.substring(0, maximo - 1) + "…";
    }

    private void menuExportaciones() {
        int opcion;
        do {
            System.out.println("\n---------- EXPORTAR PRODUCTOS ----------");
            System.out.println("1. Exportar productos a JSON");
            System.out.println("2. Exportar productos a XML");
            System.out.println("0. Volver al menú principal");
            opcion = LectorConsola.leerOpcion("Selecciona una opción: ", 0, 2);
            switch (opcion) {
                case 1 -> exportar("JSON", exportadorJson);
                case 2 -> exportar("XML", exportadorXml);
                case 0 -> { }
                default -> throw new IllegalStateException("Opción inesperada");
            }
        } while (opcion != 0);
    }

    /**
     * RF-FIC-05: pide la ruta, confirma la sobrescritura y delega la exportación.
     * @param formato    texto para los mensajes ("JSON" o "XML")
     * @param exportador objeto que sabe escribir ese formato
     */
    private void exportar(String formato, ExportadorCatalogo exportador) {
        System.out.println("\n===== EXPORTAR " + formato + " =====");
        if (avisarSiVacio()) {
            return;
        }
        String texto = LectorConsola.leerTexto("Ruta de destino: ");
        try {
            Path destino = ComprobadorRutas.destinoEscribible(texto);
            if (!confirmarSobrescritura(destino)) {
                System.out.println("Exportación cancelada. El fichero existente no se ha modificado.");
            } else {
                List<Producto> productos = inventario.listarOrdenado();
                exportador.exportar(productos, destino);
                System.out.println(ColoresConsola.pintar("Fichero generado correctamente.", ColoresConsola.VERDE));
                System.out.println("Ruta: " + destino.toAbsolutePath());
                System.out.println("Formato: " + formato + " | Productos exportados: " + productos.size());
            }
        } catch (ExportacionException ex) {
            System.out.println(ColoresConsola.pintar("Exportación cancelada: " + ex.getMessage(), ColoresConsola.ROJO));
        }
        LectorConsola.pausar();
    }

    /** @return true si el fichero no existe o el usuario acepta sobrescribirlo */
    private boolean confirmarSobrescritura(Path destino) {
        return !Files.exists(destino)
                || LectorConsola.confirmar("El fichero " + destino.getFileName() + " ya existe. ¿Sobrescribirlo?");
    }

    private void menuSerializacion() {
        int opcion;
        do {
            System.out.println("\n---------- GUARDAR Y RECUPERAR INVENTARIO ----------");
            System.out.println("1. Guardar inventario en fichero .dat");
            System.out.println("2. Recuperar inventario desde fichero .dat");
            System.out.println("0. Volver al menú principal");
            opcion = LectorConsola.leerOpcion("Selecciona una opción: ", 0, 2);
            switch (opcion) {
                case 1 -> guardarInventario();
                case 2 -> recuperarInventario();
                case 0 -> { }
                default -> throw new IllegalStateException("Opción inesperada");
            }
        } while (opcion != 0);
    }

    /** RF-FIC-06.1: serializa el inventario completo en un .dat. */
    private void guardarInventario() {
        System.out.println("\n===== GUARDAR INVENTARIO =====");
        if (avisarSiVacio()) {
            return;
        }
        String texto = LectorConsola.leerTexto("Ruta del fichero .dat: ");
        try {
            Path destino = ComprobadorRutas.destinoEscribible(texto);
            if (!confirmarSobrescritura(destino)) {
                System.out.println("Guardado cancelado. El fichero existente no se ha modificado.");
            } else {
                serializador.guardar(inventario.listarOrdenado(), destino);
                System.out.println(ColoresConsola.pintar("Inventario guardado correctamente.", ColoresConsola.VERDE));
                System.out.println("Ruta: " + destino.toAbsolutePath());
                System.out.println("Productos guardados: " + inventario.tamano());
            }
        } catch (ExportacionException ex) {
            System.out.println(ColoresConsola.pintar("Guardado cancelado: " + ex.getMessage(), ColoresConsola.ROJO));
        }
        LectorConsola.pausar();
    }

    /**
     * RF-FIC-06.2: lee y valida un .dat completo y, solo si todo es correcto
     * y el usuario lo confirma, sustituye el inventario actual.
     */
    private void recuperarInventario() {
        System.out.println("\n===== RECUPERAR INVENTARIO =====");
        String texto = LectorConsola.leerTexto("Ruta del fichero .dat: ");
        try {
            Path origen = ComprobadorRutas.ficheroLegible(texto);
            List<Producto> recuperados = serializador.recuperar(origen);
            if (!inventario.estaVacio()) {
                System.out.println("Actualmente hay " + inventario.tamano() + " productos en memoria. "
                        + "La recuperación sustituirá el inventario actual.");
                if (!LectorConsola.confirmar("¿Continuar?")) {
                    System.out.println("Recuperación cancelada. Se conserva el inventario actual.");
                    LectorConsola.pausar();
                    return;
                }
            }
            inventario.sustituirTodo(recuperados);
            System.out.println(ColoresConsola.pintar("Inventario recuperado correctamente.", ColoresConsola.VERDE));
            System.out.println("Productos disponibles: " + inventario.tamano());
        } catch (ImportacionException ex) {
            System.out.println(ColoresConsola.pintar("Recuperación cancelada: " + ex.getMessage(), ColoresConsola.ROJO));
            System.out.println("El inventario en memoria no ha cambiado.");
        }
        LectorConsola.pausar();
    }
}
